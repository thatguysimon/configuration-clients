# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['twist_configuration_client']

package_data = \
{'': ['*']}

install_requires = \
['PyYAML==5.3.1',
 'hvac==0.2.17',
 'invoke==1.4.0',
 'json5==0.8.5',
 'requests>=2.22.0,<3.0.0',
 'termcolor==1.1.0']

setup_kwargs = {
    'name': 'twist-configuration-client',
    'version': '0.1.11112',
    'description': 'Twist Configuration SDK',
    'long_description': None,
    'author': 'Orenus',
    'author_email': 'osea@twistbioscience.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
